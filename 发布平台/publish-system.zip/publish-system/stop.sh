forever stop  publish-system
