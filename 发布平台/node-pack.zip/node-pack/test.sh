tar xf  ./node-v14.8.0-linux-x64.tar.xz
ln -sf $(pwd)/node-v14.8.0-linux-x64/bin/npm /usr/local/bin/
ln -sf $(pwd)/node-v14.8.0-linux-x64/bin/node /usr/local/bin/
ln -sf $(pwd)/forever-pack/node_modules/forever/bin/forever /usr/local/bin/
chmod 777 ./forever-pack/node_modules/forever/bin/forever
tar xf  ./project.tar.xz
cd project
forever start bin/www
yum install -y nginx-1.16.1-1.el7.ngx.x86_64.rpm
service nginx start
rpm -ivh unzip-6.0-5.el6.x86_64.rpm
